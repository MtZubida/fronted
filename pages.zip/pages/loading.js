
export default function GetUsers({ data }) {
    
    return (
        <>
     <h1>your page is loading</h1>
      </>
    );
    }