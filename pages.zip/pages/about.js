import MyLayout from "./component/layout"
import Header from "./component/header"
export default function About() {
    return (
      <>
      
      <MyLayout title="About"/>

      <h1>About</h1>
      <h3>About the orgnaization</h3>
      </>
    )
  }
  