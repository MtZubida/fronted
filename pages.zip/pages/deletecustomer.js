import Link from "next/link"
export default function DeleteCustomer() {
  return (
    <>
  
     
    </>
  )
}
