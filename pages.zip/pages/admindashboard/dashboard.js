import Link from "next/link"
export default function Dashboard() {
  return (
    <>
  
     <h1>Dashboard</h1>
     <Link href="/addcustomer">Add Customer</Link><br></br>
    
     <Link href="/modifycustomer">Modify Customer</Link><br></br>
     <Link href="/searchcustomer">Search Customer</Link><br></br>
     <Link href="/deletecustomer">Delete Customer</Link><br></br>


     <Link href="/addseller">Add Seller</Link><br></br>
    
     <Link href="/modifyseller">Modify Seller</Link><br></br>
     <Link href="/searchseller">Search Seller</Link><br></br>
     <Link href="/deleteseller">Delete Seller</Link><br></br>

     <Link href="/addmodaretor">Add modaretor</Link><br></br>
    
     <Link href="/modifymodaretor">Modify modaretor</Link><br></br>
     <Link href="/searchmodaretor">Search moderator</Link><br></br>
     <Link href="/deletemodaretor">Delete moderator</Link><br></br>


    </>
  )
}
